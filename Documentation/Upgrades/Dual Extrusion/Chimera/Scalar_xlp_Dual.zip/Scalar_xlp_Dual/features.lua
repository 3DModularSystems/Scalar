version = 2

bed_size_x_mm = 400
bed_size_y_mm = 300
bed_size_z_mm = 300
travel_speed_mm_per_sec = 90

add_setting('extruder_offset_x_setting', 'Extruder offset X', 0, 200)
add_setting('extruder_offset_y_setting', 'Extruder offset Y', 0, 200)
extruder_offset_x_setting = 0.0
extruder_offset_y_setting = 0.0

extruder_offset_x = {}
extruder_offset_y = {}
extruder_offset_x[0] =   0.0
extruder_offset_y[0] =   0.0
extruder_offset_x[1] =   extruder_offset_x_setting
extruder_offset_y[1] =   extruder_offset_y_setting

extruder_count = 2

extruder_degrees_per_sec_0 = 1--0.4
extruder_degrees_per_sec_1 = 1--0.4

-- Requires extruder to swap material at a given location,
-- this also forces the tower to appear at this same location.
extruder_swap_at_location = true
add_setting('extruder_swap_location_x_mm', 'E-Swap location X', 0, 400)
add_setting('extruder_swap_location_y_mm', 'E-Swap location Y', 0, 300)
extruder_swap_location_x_mm = 370
extruder_swap_location_y_mm = 270
add_setting('extruder_swap_retract_length_mm', 'E-Swap Length', 0, 5)
add_setting('extruder_swap_retract_speed_mm_per_sec', 'E-Swap Speed (mm/s)', 0, 100)
extruder_swap_retract_length_mm = 10--2.2
extruder_swap_priming_extra_length_mm = 0.0
extruder_swap_retract_speed_mm_per_sec = 50.0

nozzle_diameter_mm = 0.4

priming_mm_per_sec = 50

gen_shield = true
shield_distance_to_part_mm = 2.00
shield_num_contours = 2

gen_tower = true
tower_side_x_mm = 12.0
tower_side_y_mm = 12.0
tower_brim_num_contours = 12

enable_active_temperature_control = true

z_layer_height_mm_min = 0.05
z_layer_height_mm_max = nozzle_diameter_mm * 0.75

print_speed_mm_per_sec_min = 5
print_speed_mm_per_sec_max = 80

bed_temp_degree_c_min = 0
bed_temp_degree_c_max = 120
bed_temp_degree_c     = 60

perimeter_print_speed_mm_per_sec_min = 5
perimeter_print_speed_mm_per_sec_max = 80

first_layer_print_speed_mm_per_sec = 10
first_layer_print_speed_mm_per_sec_min = 1
first_layer_print_speed_mm_per_sec_max = 80

for i=0,63,1 do
  _G['filament_diameter_mm_'..i] = 1.75
  _G['filament_priming_mm_'..i] = 2
  _G['extruder_temp_degree_c_' ..i] = 195
  _G['idle_extruder_temp_degree_c_' ..i] = 185
  _G['extruder_degrees_per_sec_' ..i] = extruder_degrees_per_sec_0
  _G['extruder_temp_degree_c_'..i..'_min'] = 185
  _G['extruder_temp_degree_c_'..i..'_max'] = 270
  _G['extruder_mix_count_'..i] = 1
end
