name_en = "ABS [1.75-0.6mm]"
name_es = "ABS [1.75-0.6mm]"
name_fr = "ABS [1.75-0.6mm]"
name_ch = "ABS [1.75-0.6mm]"

extruder_temp_degree_c_0 = 245
filament_diameter_mm_0 = 1.75
filament_priming_mm_0 = 1.5

extruder_temp_degree_c_1 = 245
filament_diameter_mm_1 = 1.75
filament_priming_mm_1 = 1.5

bed_temp_degree_c = 110
add_raft=true


enable_fan = false
enable_fan_first_layer = false
fan_speed_percent = 0
fan_speed_percent_on_bridges = 0