name_en = "PLA [1.75-0.8mm]"
name_es = "PLA [1.75-0.8mm]"
name_fr = "PLA [1.75-0.8mm]"
name_ch = "PLA [1.75-0.8mm]"

extruder_temp_degree_c_0 = 210
filament_diameter_mm_0 = 1.75
filament_priming_mm_0 = 1.5

extruder_temp_degree_c_1 = 210
filament_diameter_mm_1 = 1.75
filament_priming_mm_1 = 1.5

bed_temp_degree_c = 60

enable_fan = true
enable_fan_first_layer = true
fan_speed_percent = 100
fan_speed_percent_on_bridges = 100
